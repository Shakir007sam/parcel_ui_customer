import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-booking',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './customer-booking.html',
  styleUrls: ['./customer-booking.css'],
})
export class CustomerBooking implements OnInit{
  today:string;
  dropoffInvalid: boolean = false;
  constructor(private router:Router) {
    // Generate today in yyyy-MM-dd format
    const d = new Date();
    this.today = d.toISOString().split('T')[0];
  }
  sender = {
    name: '',
    contact: '',
    address: '',
    userId: ''
  };
  // Receiver model
  receiver = {
    name: '',
    contact: '',
    address: '',
    pincode: '',
  };
  price: number = 0;
  ngOnInit(): void {
      const customer = sessionStorage.getItem('customer');
    if (customer) {
      this.sender = JSON.parse(customer);
    }
  }
  updatePrice() {
    const weight = parseInt(this.parcel.sizeWeight, 10) || 0;

    // Base price
    const basePrice = 0;

    // Example: add 10 per weight unit
    const weightPrice = weight * 10;

    // Add insurance if checked
    const insurancePrice = this.parcel.insurance ? 3*weight : 0;

    var pakagePrice=0;
    if(this.parcel.packaging==="custom"){
      pakagePrice=parseInt(this.parcel.sizeWeight, 10)*2;
    }
    else if(this.parcel.packaging==="fragile"){
      pakagePrice=parseInt(this.parcel.sizeWeight,10)*4;
    }
    else if(this.parcel.packaging==="eco"){
      pakagePrice=parseInt(this.parcel.sizeWeight,10)*1;
    }
    const expressPrice=this.parcel.deliverySpeed==="express"?100:0;
    // Total price
    this.price = basePrice + weightPrice + insurancePrice + expressPrice+pakagePrice;

  }
  // Parcel model
  parcel = {
    sizeWeight: '',
    contents: '',
    deliverySpeed: '',
    packaging: '',
    pickupTime: '',
    dropoffTime: '',
    paymentMethod: '',
    insurance: null,
    tracking: false,
  };
  validateDropoffDate() {
  this.dropoffInvalid = false;

  if (this.parcel.pickupTime && this.parcel.dropoffTime) {
    const pickup = new Date(this.parcel.pickupTime);
    const dropoff = new Date(this.parcel.dropoffTime);

    if (dropoff <= pickup) {
      this.dropoffInvalid = true;
    }
  }
}
  // Called on form submit
  onSubmit(form: NgForm) {
    if (form.valid) {
      const senderInfo = {
      name: this.sender.name,      // or fetch from readonly inputs
      contact: this.sender.contact,
      address: this.sender.address
    };

    // Collect parcel, receiver, payment info
    const bookingData = {
      sender: senderInfo,
      receiver: this.receiver,
      parcel: this.parcel,
      payment: {
        cost: this.price,
        method: this.parcel.paymentMethod,
        dateTime: new Date().toLocaleString()
      }
    };

    // Store the whole booking data in session storage
    sessionStorage.setItem('bookingData', JSON.stringify(bookingData));

    // Navigate to invoice page
    this.router.navigate(['/customer-invoice']);
      console.log('Booking submitted:', { receiver: this.receiver, parcel: this.parcel });
      alert('Booking submitted successfully!');
      // reset form and models
      form.resetForm({
        receiver: { name: '', contact: '', address: '', pincode: '' },
        parcel: {
          sizeWeight: '',
          contents: '',
          deliverySpeed: '',
          packaging: '',
          pickupTime: '',
          dropoffTime: '',
          paymentMethod: '',
          insurance: null,
          tracking: false,
        },
      });
    } else {
      // mark controls as touched so validation shows
      form.control.markAllAsTouched();
    }
  }
}
