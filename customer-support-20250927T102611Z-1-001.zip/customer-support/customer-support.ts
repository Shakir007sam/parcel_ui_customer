import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-customer-support',
  imports: [RouterLink],
  templateUrl: './customer-support.html',
  styleUrl: './customer-support.css'
})
export class CustomerSupport {
  username:string='soham'
}
