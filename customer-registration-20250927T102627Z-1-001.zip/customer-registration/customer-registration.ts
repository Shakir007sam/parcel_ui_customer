import { NgClass, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../services/customer';

@Component({
  selector: 'app-customer-registration',
  standalone: true,
  imports: [FormsModule, NgClass, NgIf],
  templateUrl: './customer-registration.html',
  styleUrls: ['./customer-registration.css']
})
export class CustomerRegistration {
  // Form model
  constructor(private customerService:CustomerService,private router:Router){

  }
  customer = {
    name: '',
    email: '',
    countryCode: '',
    mobile: '',
    address: '',
    userId: '',
    password: '',
    confirmPassword: '',
    preferences: ''
  };

  submitted = false;

  // Real-time validation flags
  isNameValid = true;
  isEmailValid = true;
  isMobileValid = true;
  isUserIdValid = true;
  isPasswordValid = true;
  isConfirmPasswordValid = true;

  // Real-time validation functions
  checkName() {
    this.isNameValid = this.customer.name.trim().length > 0;
  }

  checkEmail() {
    const regex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
    this.isEmailValid = regex.test(this.customer.email);
  }

  checkMobile() {
    const regex = /^[0-9]{10}$/;
    this.isMobileValid = regex.test(this.customer.mobile);
  }

  checkUserId() {
    const len = this.customer.userId.trim().length;
    this.isUserIdValid = len >= 5 && len <= 20;
  }

  checkPassword() {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{6,30}$/;
    this.isPasswordValid = regex.test(this.customer.password);
  }

  checkConfirmPassword() {
    this.isConfirmPasswordValid = this.customer.password === this.customer.confirmPassword;
  }

  // Called whenever a field changes
  validateField(field: string) {
    switch(field) {
      case 'name': this.checkName(); break;
      case 'email': this.checkEmail(); break;
      case 'mobile': this.checkMobile(); break;
      case 'userId': this.checkUserId(); break;
      case 'password': this.checkPassword(); break;
      case 'confirmPassword': this.checkConfirmPassword(); break;
    }
  }

  onSubmit(form: NgForm) {
    this.submitted = true;

    // Recheck all validations
    this.checkName();
    this.checkEmail();
    this.checkMobile();
    this.checkUserId();
    this.checkPassword();
    this.checkConfirmPassword();

    if (
      form.valid &&
      this.isNameValid &&
      this.isEmailValid &&
      this.isMobileValid &&
      this.isUserIdValid &&
      this.isPasswordValid &&
      this.isConfirmPasswordValid
    ) {

      alert('Registration successful!');
      form.resetForm();
      this.submitted = false;
      this.router.navigate(['/customer-login']);
    //   this.customerService.registerCustomer(this.customer).subscribe({
    //   next: (res) => {
    //     alert('Registration successful!');
    //     form.resetForm();
    //     this.submitted = false;
    //     this.router.navigate(['/customer-login']); // navigate to login page
    //   },
    //   error: (err) => {
    //     console.error(err);
    //     alert('Registration failed. Please try again.');
    //   }
    // });
    }
  }
}
