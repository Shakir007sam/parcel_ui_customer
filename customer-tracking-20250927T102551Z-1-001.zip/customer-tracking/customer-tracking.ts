import { CommonModule } from '@angular/common';
import { Component} from '@angular/core';
import { FormsModule ,NgForm} from '@angular/forms';
import { RouterLink, RouterModule ,RouterLinkActive} from '@angular/router';

@Component({
  selector: 'app-customer-tracking',
  standalone: true,
  imports: [FormsModule,CommonModule,RouterModule,RouterLink,RouterLinkActive],
  templateUrl: './customer-tracking.html'
})
export class CustomerTracking {
  bookingId: string = '';
  submitted = false;
  username:string='soham'
  status: { currentStatus: string; estimatedDate: string } | null = null;

  // Real-time validity flag
  isBookingIdValid: boolean = false;

  // Called on every input
  checkBookingId() {
    const regex = /^[0-9]{12}$/;
    this.isBookingIdValid = regex.test(this.bookingId);
  }

  onSubmit(form: NgForm) {
    this.submitted = true;

    if (form.valid && this.isBookingIdValid) {
      // Simulate fetching parcel status
      this.status = {
        currentStatus: 'In Transit',
        estimatedDate: '2025-09-12'
      };
    } else {
      this.status = null;
    }
  }
}
