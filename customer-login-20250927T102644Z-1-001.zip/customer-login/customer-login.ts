import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CustomerService } from '../services/customer'; // ✅ import service

@Component({
  selector: 'app-customer-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './customer-login.html',
  styleUrl: './customer-login.css',
})
export class CustomerLoginComponent {
  userId = signal('');
  password = signal('');

  // Real-time error signals
  userIdError = signal('');
  passwordError = signal('');
  loginError = signal(''); // ✅ for showing API error

  constructor(
    private router: Router,
    private customerService: CustomerService // ✅ inject service
  ) {}

  // Validation logic
  validateUserId() {
    const val = this.userId();
    if (val.length < 5 || val.length > 20) {
      this.userIdError.set('User ID must be between 5 and 20 characters.');
    } else {
      this.userIdError.set('');
    }
  }

  validatePassword() {
    const val = this.password();
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{6,30}$/;
    if (!regex.test(val)) {
      this.passwordError.set(
        'Password must contain uppercase, lowercase, and a special character.'
      );
    } else {
      this.passwordError.set('');
    }
  }

  login() {
    // Don’t call API if validation errors exist
    if (this.userIdError() || this.passwordError()) {
      this.loginError.set('Please fix validation errors first.');
      return;
    }
    if (this.userId() === 'soham' && this.password() === 'Soham@2020') {
      this.router.navigate(['customer-home']);
    } else {
      alert('Invalid Username / Password');
    }
    const credentials = {
      userId: this.userId(),
      password: this.password(),
    };

    // this.customerService.login(credentials).subscribe({
    //   next: (res: any) => {
    //     // Assume backend sends { message: "Customer logged in successfully" }
    //     if (res.message?.includes('success')) {
    //       const senderInfo = {
    //         name: res.name,
    //         contact: res.contact,
    //         address: res.address,
    //         userId: res.userId,
    //       };

    //       // Store in session storage
    //       sessionStorage.setItem('customer', JSON.stringify(senderInfo));
    //       this.router.navigate(['customer-home']);
    //     } else {
    //       this.loginError.set(res.message || 'Invalid credentials.');
    //     }
    //   },
    //   error: (err: any) => {
    //     this.loginError.set('Login failed. Please check your credentials.');
    //     console.error(err);
    //   },
    // });
  }
}
