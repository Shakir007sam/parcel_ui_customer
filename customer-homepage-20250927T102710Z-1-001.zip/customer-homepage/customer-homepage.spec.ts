import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerHomepage } from './customer-homepage';

describe('CustomerHomepage', () => {
  let component: CustomerHomepage;
  let fixture: ComponentFixture<CustomerHomepage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomerHomepage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerHomepage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
