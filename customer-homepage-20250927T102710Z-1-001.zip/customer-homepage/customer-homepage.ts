import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
@Component({
  selector: 'app-customer-homepage',
  imports: [RouterLink],
  templateUrl: './customer-homepage.html',
  styleUrl: './customer-homepage.css'
})
export class CustomerHomepage {
  username:string='user'
}
