import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-invoice',
  imports: [],
  templateUrl: './customer-invoice.html',
  styleUrl: './customer-invoice.css'
})
export class CustomerInvoice implements OnInit{
  constructor(private router:Router){}
  sender: any = {};
  receiver: any = {};
  parcel: any = {};
  payment: any = {};

  ngOnInit() {
    const data = sessionStorage.getItem('bookingData');
    if (data) {
      const booking = JSON.parse(data);
      this.sender = booking.sender;
      this.receiver = booking.receiver;
      this.parcel = booking.parcel;
      this.payment = booking.payment;
    }
  }
  printInvoice() {
    window.print();
    sessionStorage.removeItem('bookingData');
    this.router.navigate(['/customer-home']);
  }
}
