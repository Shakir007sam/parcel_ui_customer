import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
export interface SenderInfo {
  name: string;
  contact: string;
  address: string;
  userId: string;
}
export interface Customer {
  name: string;
  email: string;
  countryCode: string;
  mobile: string;
  address: string;
  userId: string;
  password: string;
}
export interface Booking{
  customerId: string,
      bookingId: string,
      bookingDate: string,
      receiverName: string,
      deliveredAddress: string,
      amount: number,
      status: string,
}
@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private apiUrl = 'http://localhost:8080/api';
  constructor(private http: HttpClient) {}

  /** Login API */
  login(credentials: { userId: string; password: string }): Observable<SenderInfo> {
    return this.http.post<SenderInfo>(`${this.apiUrl}/login`, credentials);
  }
  // Register customer API
  registerCustomer(customerData: any): Observable<Customer> {
    return this.http.post<Customer>(`${this.apiUrl}/register`, customerData);
  }
  // 📌 Call Booking API
  createBooking(bookingData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/bookings`, bookingData);
  }
  // 📌 Get Booking by ID (optional, for invoice)
  getBookingById(id: number): Observable<Booking> {
    return this.http.get<Booking>(`${this.apiUrl}/bookings/${id}`);
  }
  getAllBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.apiUrl}/bookings`);
  }
}
