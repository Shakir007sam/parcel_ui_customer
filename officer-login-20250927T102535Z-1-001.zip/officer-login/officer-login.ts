import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-officer-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './officer-login.html',
  styleUrls: ['./officer-login.css']
})
export class OfficerLoginComponent {
  userId = signal('');
  password = signal('');

  userIdError = signal('');
  passwordError = signal('');

  validateUserId() {
    const val = this.userId();
    if (val.length < 5 || val.length > 20) {
      this.userIdError.set('User ID must be between 5 and 20 characters.');
    } else {
      this.userIdError.set('');
    }
  }

  validatePassword() {
    const val = this.password();
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{1,30}$/;
    if (!regex.test(val)) {
      this.passwordError.set('Password must contain uppercase, lowercase, and a special character.');
    } else {
      this.passwordError.set('');
    }
  }
}
