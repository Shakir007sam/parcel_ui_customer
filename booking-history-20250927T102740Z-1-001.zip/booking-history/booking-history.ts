
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-booking-history',
  standalone:true,
  imports:[RouterLink],
  templateUrl: './booking-history.html',
  styleUrls: ['./booking-history.css'],
})
export class BookingHistory {
  username = 'Soham'; // Replace with actual logged-in user

  bookings = [
    {
      customerId: 'CUST12345',
      bookingId: 'BK1234567890',
      bookingDate: '2025-09-05',
      receiverName: 'John Doe',
      deliveredAddress: '123 Elm Street, Cityville',
      amount: 45,
      status: 'Delivered',
    },
    {
      customerId: 'CUST12345',
      bookingId: 'BK0987654321',
      bookingDate: '2025-08-28',
      receiverName: 'Jane Smith',
      deliveredAddress: '456 Oak Avenue, Townsville',
      amount: 30,
      status: 'In Transit',
    },
  ];

  currentPage = 1;

  logout() {
    console.log('Logging out...');
    // TODO: redirect to welcome page
  }

  nextPage() {
    this.currentPage++;
    console.log('Next Page:', this.currentPage);
  }

  prevPage() {
    if (this.currentPage > 1) this.currentPage--;
    console.log('Previous Page:', this.currentPage);
  }
}
